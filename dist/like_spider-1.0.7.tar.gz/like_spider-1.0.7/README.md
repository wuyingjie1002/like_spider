like spider: a crawler framework that allows developers to easily extract web page information and quickly store data.

author: wyjhaha@foxmail.com

github: https://github.com/wuyingjie1002/like_spider

Note: please read the development documentation and sample code in detail during development, development documentation can be found in the doc directory.

github wiki: https://github.com/wuyingjie1002/like_spider/wiki

If you have any questions or suggestions, please contact me by email.

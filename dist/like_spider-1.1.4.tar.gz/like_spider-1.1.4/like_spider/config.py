import sys

DB_HOST = sys.modules['DB_HOST']

DB_USER = sys.modules['DB_USER']

DB_PASSWORD = sys.modules['DB_PASSWORD']

DB_PORT = sys.modules['DB_PORT']

DB_NAME = sys.modules['DB_NAME']

DB_CHARSET = sys.modules['DB_CHARSET']

TIME_OUT = sys.modules['TIME_OUT']

HEADERS = sys.modules['HEADERS']

PROXIES = sys.modules['PROXIES']

FIREFOX_DRIVER = sys.modules['FIREFOX_DRIVER']

WAIT_TIME = sys.modules['WAIT_TIME']

LOG_DIR = sys.modules['LOG_DIR']

EXCEL_DIR = sys.modules['EXCEL_DIR']
